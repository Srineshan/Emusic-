from django.contrib import admin
from .models import r_data

# Register your models here.

admin.site.register(r_data)
